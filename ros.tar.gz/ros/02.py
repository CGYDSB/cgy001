from lerobot_robot_viola.starai_viola import StaraiViola
from lerobot_robot_viola.config_starai_viola import StaraiViolaConfig
from pathlib import Path
import time

config = StaraiViolaConfig(
    port="/dev/ttyUSB0",
    id="my_awesome_staraiviola_arm",
    calibration_dir=Path.home() / ".cache/huggingface/lerobot/calibration/robots/starai_viola",
)

arm = StaraiViola(config)
arm.connect(calibrate=False)

MOTION_TIME = 3000
SLEEP = 3.5

# 初始位：大臂抬起，小臂折叠收起
HOME = {"Motor_0": 0, "Motor_1": -100, "Motor_2": 60, "Motor_3": 0, "Motor_4": 30, "Motor_5": 0, "gripper": 50}

def move(action):
    arm.bus.sync_write("Goal_Position", action, motion_time=MOTION_TIME)
    time.sleep(SLEEP)

move(HOME)

# 1. 底座左转，保持大臂抬起
move({"Motor_0": 60,  "Motor_1": -100, "Motor_2": 60,  "Motor_3": 0,  "Motor_4": 30, "Motor_5": 0,  "gripper": 50})

# 2. 大臂缓慢前倾，小臂展开（不碰桌面）
move({"Motor_0": 60,  "Motor_1": -40,  "Motor_2": 0,   "Motor_3": 0,  "Motor_4": 20, "Motor_5": 0,  "gripper": 50})

# 3. 腕部俯仰 + 小臂旋转
move({"Motor_0": 60,  "Motor_1": -40,  "Motor_2": 0,   "Motor_3": 50, "Motor_4": 60, "Motor_5": 50, "gripper": 50})

# 4. 腕部反向旋转
move({"Motor_0": 60,  "Motor_1": -40,  "Motor_2": 0,   "Motor_3": -50,"Motor_4": 60, "Motor_5": -50,"gripper": 50})

# 5. 收臂回中
move({"Motor_0": 0,   "Motor_1": -70,  "Motor_2": 40,  "Motor_3": 0,  "Motor_4": 30, "Motor_5": 0,  "gripper": 50})

# 6. 底座右转，大臂前倾
move({"Motor_0": -60, "Motor_1": -40,  "Motor_2": 0,   "Motor_3": 0,  "Motor_4": 20, "Motor_5": 0,  "gripper": 50})

# 7. 腕部俯仰 + 旋转
move({"Motor_0": -60, "Motor_1": -40,  "Motor_2": 0,   "Motor_3": 50, "Motor_4": 60, "Motor_5": 50, "gripper": 50})

# 8. 腕部反向
move({"Motor_0": -60, "Motor_1": -40,  "Motor_2": 0,   "Motor_3": -50,"Motor_4": 60, "Motor_5": -50,"gripper": 50})

# 9. 回初始位
move({"Motor_0": -30, "Motor_1": -70,  "Motor_2": 40,  "Motor_3": 0,  "Motor_4": 30, "Motor_5": 0,  "gripper": 50})
move(HOME)

print("完成")
arm.disconnect()
