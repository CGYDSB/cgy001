from lerobot_robot_viola.starai_viola import StaraiViola
from lerobot_robot_viola.config_starai_viola import StaraiViolaConfig
from pathlib import Path
import time

config = StaraiViolaConfig(
    port="/dev/ttyUSB0",
    id="my_awesome_staraiviola_arm",
    calibration_dir=Path.home() / ".cache/huggingface/lerobot/calibration/robots/starai_viola",
)

arm = StaraiViola(config)
arm.connect(calibrate=False)

# 位置范围：Motor_0~5 是 -100 到 100，gripper 是 0 到 100
arm.send_action({
    "Motor_0.pos": 0,
    "Motor_1.pos": -100,
    "Motor_2.pos": 60,
    "Motor_3.pos": 0,
    "Motor_4.pos": 30,
    "Motor_5.pos": 0,
    "gripper.pos": 50,
})

time.sleep(2)

pos = arm.get_action()
print(pos)

arm.disconnect()
