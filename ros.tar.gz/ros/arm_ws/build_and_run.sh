#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

source /opt/ros/humble/setup.bash
colcon build --symlink-install
source install/setup.bash

echo ""
echo "====== 构建完成，使用方式 ======"
echo ""
echo "# 每个终端先执行:"
echo "  source /opt/ros/humble/setup.bash && source $SCRIPT_DIR/install/setup.bash"
echo ""
echo "## 1. Mock 模式 (无需仿真器，默认)"
echo "  ros2 launch simple_arm arm_bringup.launch.py"
echo "  ros2 run simple_arm arm_demo"
echo ""
echo "## 2. Gazebo 仿真模式"
echo "  ros2 launch simple_arm arm_bringup.launch.py use_sim:=true"
echo "  ros2 run simple_arm arm_demo"
echo ""
echo "## 3. 真实硬件模式"
echo "  ros2 launch simple_arm arm_bringup.launch.py hardware_type:=real"
echo "  ros2 run simple_arm arm_demo"
echo ""
echo "## 4. MoveIt2 规划模式 (任意后端均可)"
echo "  ros2 launch simple_arm arm_bringup.launch.py use_moveit:=true"
echo "  ros2 run simple_arm arm_demo --ros-args -p mode:=moveit"
echo ""
echo "## 5. 手动发单个目标"
echo "  ros2 topic pub --once /arm_controller/joint_trajectory \\"
echo "    trajectory_msgs/msg/JointTrajectory \\"
echo "    '{joint_names: [joint1,joint2,joint3,joint4,joint5,joint6],\\"
echo "      points: [{positions: [0.5,0.3,-0.3,0.0,0.2,0.0], time_from_start: {sec: 2}}]}'"
