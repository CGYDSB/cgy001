from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'simple_arm'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'config', 'moveit'), glob('config/moveit/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='developer',
    maintainer_email='dev@example.com',
    description='Simple 6-DOF arm demo for ROS2 Humble',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'arm_demo = simple_arm.arm_controller_demo:main',
            'yolo_detector = simple_arm.yolo_detector:main',
            'inspection_task = simple_arm.inspection_task:main',
        ],
    },
)
