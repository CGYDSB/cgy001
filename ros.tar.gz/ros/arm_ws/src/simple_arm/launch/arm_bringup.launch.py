"""
arm_bringup.launch.py
支持三种模式:
  ros2 launch simple_arm arm_bringup.launch.py                        # mock (默认)
  ros2 launch simple_arm arm_bringup.launch.py use_sim:=true          # Gazebo
  ros2 launch simple_arm arm_bringup.launch.py hardware_type:=real    # 真实硬件
"""
import os
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument, RegisterEventHandler,
    IncludeLaunchDescription, OpaqueFunction
)
from launch.conditions import IfCondition, UnlessCondition
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory
import xacro


def launch_setup(context, *args, **kwargs):
    pkg_path = get_package_share_directory('simple_arm')

    use_sim       = LaunchConfiguration('use_sim').perform(context)
    hardware_type = LaunchConfiguration('hardware_type').perform(context)
    use_moveit    = LaunchConfiguration('use_moveit').perform(context)

    # use_sim=true 时强制 hardware_type=gazebo
    if use_sim == 'true':
        hardware_type = 'gazebo'

    use_sim_time = (use_sim == 'true')

    # ---- 解析 URDF ----
    xacro_file = os.path.join(pkg_path, 'urdf', 'simple_arm.urdf.xacro')
    robot_description = xacro.process_file(
        xacro_file,
        mappings={'hardware_type': hardware_type}
    ).toxml()

    controllers_yaml   = os.path.join(pkg_path, 'config', 'controllers.yaml')
    moveit_srdf        = os.path.join(pkg_path, 'config', 'moveit', 'simple_arm.srdf')
    kinematics_yaml    = os.path.join(pkg_path, 'config', 'moveit', 'kinematics.yaml')
    ompl_yaml          = os.path.join(pkg_path, 'config', 'moveit', 'ompl_planning.yaml')
    moveit_ctrl_yaml   = os.path.join(pkg_path, 'config', 'moveit', 'moveit_controllers.yaml')

    robot_description_param      = {'robot_description': robot_description}
    robot_description_semantic   = {'robot_description_semantic': open(moveit_srdf).read()}

    nodes = []

    # ---- robot_state_publisher ----
    nodes.append(Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[robot_description_param, {'use_sim_time': use_sim_time}],
    ))

    # ---- Gazebo 模式 ----
    if use_sim == 'true':
        gazebo = IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([FindPackageShare('gazebo_ros'), 'launch', 'gazebo.launch.py'])
            ]),
            launch_arguments={'pause': 'false'}.items(),
        )
        spawn_entity = Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=['-topic', 'robot_description', '-entity', 'simple_arm'],
            output='screen',
        )
        nodes.extend([gazebo, spawn_entity])
    else:
        # mock / real: 用 ros2_control_node 驱动
        nodes.append(Node(
            package='controller_manager',
            executable='ros2_control_node',
            parameters=[robot_description_param, controllers_yaml],
            output='screen',
        ))

    # ---- 控制器 spawner ----
    load_jsb = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager'],
        output='screen',
    )
    load_arm = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['arm_controller', '--controller-manager', '/controller_manager'],
        output='screen',
    )
    # arm_controller 等 jsb 就绪后再加载
    load_arm_after_jsb = RegisterEventHandler(
        event_handler=OnProcessExit(target_action=load_jsb, on_exit=[load_arm])
    )
    nodes.extend([load_jsb, load_arm_after_jsb])

    # ---- MoveIt2 move_group ----
    if use_moveit == 'true':
        move_group = Node(
            package='moveit_ros_move_group',
            executable='move_group',
            output='screen',
            parameters=[
                robot_description_param,
                robot_description_semantic,
                {'use_sim_time': use_sim_time},
                kinematics_yaml,
                ompl_yaml,
                moveit_ctrl_yaml,
                {'publish_robot_description_semantic': True},
                {'allow_trajectory_execution': True},
                {'publish_planning_scene': True},
                {'publish_geometry_updates': True},
                {'publish_state_updates': True},
                {'publish_transforms_updates': True},
            ],
        )
        nodes.append(move_group)

    # ---- RViz2 ----
    rviz_config = os.path.join(pkg_path, 'config', 'arm_view.rviz')
    rviz_args = ['-d', rviz_config] if os.path.exists(rviz_config) else []
    nodes.append(Node(
        package='rviz2',
        executable='rviz2',
        arguments=rviz_args,
        parameters=[
            robot_description_param,
            robot_description_semantic,
            kinematics_yaml,
            {'use_sim_time': use_sim_time},
        ],
        output='screen',
    ))

    return nodes


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('use_sim',       default_value='false',
                              description='true=Gazebo仿真, false=mock或真实硬件'),
        DeclareLaunchArgument('hardware_type', default_value='mock',
                              description='mock | gazebo | real'),
        DeclareLaunchArgument('use_moveit',    default_value='true',
                              description='是否启动 MoveIt2 move_group'),
        OpaqueFunction(function=launch_setup),
    ])
