#!/usr/bin/env python3
"""
inspection_task.py
巡检任务主节点：依次移动到预设位置 → 等待 YOLO 检测 → 移动到下一个位置。

用法:
  ros2 run simple_arm inspection_task
  ros2 run simple_arm inspection_task --ros-args -p detect_timeout:=5.0
"""

import json
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.callback_groups import ReentrantCallbackGroup
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from builtin_interfaces.msg import Duration
from std_msgs.msg import String


JOINT_NAMES = ['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

# 预设巡检位置: (名称, [j1..j6 弧度])
# 根据你的实际机械臂修改这些关节角度
INSPECTION_POSES = [
    ("position_1", [0.0,   0.3,  -0.3,  0.0,  0.3,  0.0]),
    ("position_2", [0.8,   0.3,  -0.3,  0.0,  0.3,  0.0]),
    ("position_3", [-0.8,  0.3,  -0.3,  0.0,  0.3,  0.0]),
    ("position_4", [0.0,   0.6,  -0.5,  0.0,  0.4,  0.0]),
]


class InspectionTask(Node):
    def __init__(self):
        super().__init__('inspection_task')

        self.declare_parameter('detect_timeout', 3.0)   # 每个位置等待检测的秒数
        self.declare_parameter('move_duration',  3.0)   # 每段运动时长(秒)

        self.detect_timeout = self.get_parameter('detect_timeout').get_parameter_value().double_value
        self.move_duration  = self.get_parameter('move_duration').get_parameter_value().double_value

        self.cb_group = ReentrantCallbackGroup()

        # 订阅检测结果
        self.latest_detection = None
        self.create_subscription(
            String, '/detection_result', self._detection_cb, 10,
            callback_group=self.cb_group
        )

        # 连接 arm_controller action server
        self._action_client = ActionClient(
            self, FollowJointTrajectory,
            '/arm_controller/follow_joint_trajectory',
            callback_group=self.cb_group
        )

        self.get_logger().info('等待 arm_controller...')
        self._action_client.wait_for_server()
        self.get_logger().info('已连接，开始巡检任务')

        # 用 timer 启动任务（避免在 __init__ 里阻塞）
        self.create_timer(0.5, self._start_task, callback_group=self.cb_group)
        self._task_started = False

    def _detection_cb(self, msg: String):
        self.latest_detection = json.loads(msg.data)

    def _start_task(self):
        if self._task_started:
            return
        self._task_started = True
        self._run_inspection()

    def _run_inspection(self):
        results = []

        for idx, (name, positions) in enumerate(INSPECTION_POSES):
            self.get_logger().info(f'[{idx+1}/{len(INSPECTION_POSES)}] 移动到: {name}')

            # 发送运动目标
            success = self._move_to(positions)
            if not success:
                self.get_logger().error(f'移动到 {name} 失败，跳过')
                continue

            self.get_logger().info(f'到达 {name}，等待检测 ({self.detect_timeout}s)...')

            # 清空上一次检测结果，等待新结果
            self.latest_detection = None
            deadline = self.get_clock().now().nanoseconds + int(self.detect_timeout * 1e9)

            while self.get_clock().now().nanoseconds < deadline:
                rclpy.spin_once(self, timeout_sec=0.1)
                if self.latest_detection is not None:
                    break

            detection = self.latest_detection
            if detection:
                count = detection.get('count', 0)
                self.get_logger().info(f'  检测结果: {count} 个目标')
                for d in detection.get('detections', []):
                    self.get_logger().info(f'    - {d["class"]} (conf={d["conf"]:.2f})')
            else:
                self.get_logger().warn(f'  {name} 未收到检测结果（超时）')

            results.append({'pose': name, 'detection': detection})

        self.get_logger().info('巡检完成，返回 home')
        self._move_to([0.0] * 6)

        # 打印汇总
        self.get_logger().info('===== 巡检汇总 =====')
        for r in results:
            count = r['detection'].get('count', 0) if r['detection'] else 0
            self.get_logger().info(f"  {r['pose']}: {count} 个目标")

        rclpy.shutdown()

    def _move_to(self, positions: list) -> bool:
        """发送关节轨迹目标，阻塞等待完成，返回是否成功"""
        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = JOINT_NAMES

        pt = JointTrajectoryPoint()
        pt.positions  = [float(p) for p in positions]
        pt.velocities = [0.0] * 6
        dur = self.move_duration
        pt.time_from_start = Duration(sec=int(dur), nanosec=int((dur % 1) * 1e9))
        goal.trajectory.points.append(pt)

        future = self._action_client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, future)

        gh = future.result()
        if not gh or not gh.accepted:
            return False

        result_future = gh.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)

        code = result_future.result().result.error_code
        return code == FollowJointTrajectory.Result.SUCCESSFUL


def main(args=None):
    rclpy.init(args=args)
    node = InspectionTask()
    rclpy.spin(node)


if __name__ == '__main__':
    main()
