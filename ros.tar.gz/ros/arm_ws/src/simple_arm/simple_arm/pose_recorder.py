"""
pose_recorder.py - 手动示教位置记录与回放工具

# 录制：手动移动机械臂到位置，按 Enter 记录，可以给每个位置起名字
python arm_ws/src/simple_arm/simple_arm/pose_recorder.py --record

# 回放：选择单个位置或全部顺序回放
python arm_ws/src/simple_arm/simple_arm/pose_recorder.py --play
输入 1,2       → pose_1 → pose_2 → HOME
输入 2,1,3     → pose_2 → pose_1 → pose_3 → HOME
输入 1         → 只去 pose_1 → HOME
直接回车       → 全部顺序执行


# 查看已录制的所有位置
python arm_ws/src/simple_arm/simple_arm/pose_recorder.py --list

"""
import argparse
import json
import time
from pathlib import Path
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from lerobot_robot_viola.starai_viola import StaraiViola
from lerobot_robot_viola.config_starai_viola import StaraiViolaConfig
from arm_motion import HOME, move

POSES_FILE = Path(__file__).parent / "recorded_poses.json"

config = StaraiViolaConfig(
    port="/dev/ttyUSB0",
    id="my_awesome_staraiviola_arm",
    calibration_dir=Path.home() / ".cache/huggingface/lerobot/calibration/robots/starai_viola",
)

# ── 录制模式 ──────────────────────────────
def record():
    # 命名本次录制文件
    session_name = input("请输入本次录制名称（直接回车使用时间戳）: ").strip()
    if not session_name:
        from datetime import datetime
        session_name = datetime.now().strftime("%Y%m%d_%H%M%S")
    save_file = POSES_FILE.parent / f"{session_name}.json"

    arm = StaraiViola(config)
    arm.connect(calibrate=False)

    poses = []
    print(f"\n=== 录制模式: {session_name} ===")
    print("机械臂力矩已关闭，可以手动移动到目标位置")
    print("按 Enter 记录当前位置（可输入位置名称），输入 q 结束录制\n")

    arm.bus.disable_torque(mode="unlocked")

    while True:
        cmd = input(f"[已记录 {len(poses)} 个位置] 输入位置名称后回车记录 / 直接回车自动命名 / q 退出: ").strip()
        if cmd.lower() == "q":
            break

        pos = arm.get_action()
        pos = {k.removesuffix(".pos"): round(v, 2) for k, v in pos.items()}
        name = cmd if cmd else f"pose_{len(poses) + 1}"
        poses.append({"name": name, "position": pos})
        print(f"  已记录: {name} -> {pos}\n")

    arm.bus.disable_torque(mode="unlocked")
    arm.disconnect()

    if poses:
        save_file.write_text(json.dumps(poses, indent=2, ensure_ascii=False))
        print(f"\n已保存 {len(poses)} 个位置到 {save_file}")
    else:
        print("未记录任何位置")

# ── 回放模式 ──────────────────────────────
def play():
    # 列出所有录制文件
    files = sorted(POSES_FILE.parent.glob("*.json"))
    if not files:
        print("找不到任何录制文件")
        return

    print("=== 可用录制文件 ===")
    for i, f in enumerate(files):
        print(f"  {i+1}. {f.stem}")

    choice = input("\n输入文件编号选择（直接回车使用第1个）: ").strip()
    idx = int(choice) - 1 if choice else 0
    if not (0 <= idx < len(files)):
        print("编号无效")
        return

    selected_file = files[idx]
    poses = json.loads(selected_file.read_text())
    if not poses:
        print("录制文件为空")
        return

    print("=== 回放模式 ===")
    print("已录制的位置:")
    for i, p in enumerate(poses):
        print(f"  {i+1}. {p['name']}")

    choice = input("\n输入编号回放单个位置，输入 1,2,3 按路线回放，直接回车回放全部，输入 q 退出: ").strip()
    if choice.lower() == "q":
        return

    arm = StaraiViola(config)
    arm.connect(calibrate=False)

    current = HOME

    if choice == "":
        # 回放全部
        for p in poses:
            print(f"移动到: {p['name']}")
            move(arm, current, p["position"])
            current = p["position"]
            time.sleep(0.5)
    elif "," in choice:
        # 按路线回放
        indices = [int(x.strip()) - 1 for x in choice.split(",")]
        for idx in indices:
            if 0 <= idx < len(poses):
                p = poses[idx]
                print(f"移动到: {p['name']}")
                move(arm, current, p["position"])
                current = p["position"]
                time.sleep(0.5)
            else:
                print(f"编号 {idx+1} 无效，跳过")
    else:
        # 单个回放
        idx = int(choice) - 1
        if 0 <= idx < len(poses):
            p = poses[idx]
            print(f"移动到: {p['name']}")
            move(arm, current, p["position"])
            current = p["position"]
        else:
            print("编号无效")

    print("回放完成，返回初始位")
    move(arm, current, HOME)
    arm.disconnect()

# ── 主入口 ────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--record", action="store_true", help="录制模式")
    parser.add_argument("--play",   action="store_true", help="回放模式")
    parser.add_argument("--list",   action="store_true", help="列出已录制位置")
    args = parser.parse_args()

    if args.list:
        files = sorted(POSES_FILE.parent.glob("*.json"))
        if not files:
            print("暂无录制文件")
        for f in files:
            poses = json.loads(f.read_text())
            print(f"\n[{f.stem}] ({len(poses)} 个位置)")
            for i, p in enumerate(poses):
                print(f"  {i+1}. {p['name']}: {p['position']}")
    elif args.record:
        record()
    elif args.play:
        play()
    else:
        parser.print_help()
