#!/usr/bin/env python3
"""
arm_controller_demo.py
支持两种控制模式:
  ros2 run simple_arm arm_demo                        # 直接轨迹模式 (默认)
  ros2 run simple_arm arm_demo --ros-args -p mode:=moveit  # MoveIt2 规划模式
"""

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from builtin_interfaces.msg import Duration


# MoveIt2 Python API (moveit_py) —— Humble 需要单独安装
# 若未安装则退回到 trajectory 模式
try:
    from moveit.planning import MoveItPy
    from moveit.core.robot_state import RobotState
    MOVEIT_AVAILABLE = True
except ImportError:
    MOVEIT_AVAILABLE = False


JOINT_NAMES = ['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

# 预设姿态: (名称, [j1..j6 弧度])
POSES = [
    ("home",    [0.0,  0.0,  0.0,  0.0,  0.0,  0.0]),
    ("ready",   [0.0,  0.5, -0.3,  0.0,  0.3,  0.0]),
    ("left",    [1.0,  0.3, -0.5,  0.5,  0.2,  0.5]),
    ("right",   [-1.0, 0.3, -0.5, -0.5,  0.2, -0.5]),
    ("home",    [0.0,  0.0,  0.0,  0.0,  0.0,  0.0]),
]


class ArmDemo(Node):
    def __init__(self):
        super().__init__('arm_controller_demo')
        self.declare_parameter('mode', 'trajectory')  # trajectory | moveit
        mode = self.get_parameter('mode').get_parameter_value().string_value

        if mode == 'moveit' and MOVEIT_AVAILABLE:
            self.get_logger().info('使用 MoveIt2 规划模式')
            self._run_moveit()
        else:
            if mode == 'moveit' and not MOVEIT_AVAILABLE:
                self.get_logger().warn('moveit_py 未安装，退回到 trajectory 模式')
            self.get_logger().info('使用直接轨迹模式')
            self._run_trajectory()

    # ------------------------------------------------------------------
    # 模式1: 直接发送 JointTrajectory (不经过 MoveIt 规划)
    # ------------------------------------------------------------------
    def _run_trajectory(self):
        self._action_client = ActionClient(
            self, FollowJointTrajectory,
            '/arm_controller/follow_joint_trajectory'
        )
        self.get_logger().info('等待 arm_controller action server...')
        self._action_client.wait_for_server()
        self.get_logger().info('已连接，发送轨迹')

        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = JOINT_NAMES

        t = 0.0
        for name, positions in POSES:
            t += 2.5
            pt = JointTrajectoryPoint()
            pt.positions  = positions
            pt.velocities = [0.0] * 6
            pt.time_from_start = Duration(sec=int(t), nanosec=int((t % 1) * 1e9))
            goal.trajectory.points.append(pt)
            self.get_logger().info(f'  路径点 [{name}] @ t={t:.1f}s  {[f"{p:.2f}" for p in positions]}')

        future = self._action_client.send_goal_async(goal, feedback_callback=self._fb)
        future.add_done_callback(self._goal_resp)

    def _fb(self, fb):
        pos = fb.feedback.actual.positions
        if pos:
            self.get_logger().info(f'实际关节角: [{", ".join(f"{p:.3f}" for p in pos)}]')

    def _goal_resp(self, future):
        gh = future.result()
        if not gh.accepted:
            self.get_logger().error('目标被拒绝')
            return
        self.get_logger().info('目标已接受，执行中...')
        gh.get_result_async().add_done_callback(self._result)

    def _result(self, future):
        code = future.result().result.error_code
        if code == FollowJointTrajectory.Result.SUCCESSFUL:
            self.get_logger().info('轨迹执行完成')
        else:
            self.get_logger().error(f'执行失败，错误码: {code}')
        rclpy.shutdown()

    # ------------------------------------------------------------------
    # 模式2: 通过 MoveIt2 规划后执行
    # ------------------------------------------------------------------
    def _run_moveit(self):
        arm = MoveItPy(node_name='arm_moveit_py')
        planner = arm.get_planning_component('arm')
        self.get_logger().info('MoveIt2 已初始化')

        for name, positions in POSES:
            self.get_logger().info(f'规划到姿态: {name}')
            robot_state = RobotState(arm.get_robot_model())
            robot_state.set_joint_group_positions('arm', positions)

            planner.set_start_state_to_current_state()
            planner.set_goal_state(robot_state=robot_state)

            plan = planner.plan()
            if plan:
                self.get_logger().info(f'  规划成功，执行...')
                arm.execute(plan.trajectory, controllers=['arm_controller'])
            else:
                self.get_logger().error(f'  规划失败: {name}')

        self.get_logger().info('所有姿态执行完毕')
        rclpy.shutdown()


def main(args=None):
    rclpy.init(args=args)
    node = ArmDemo()
    rclpy.spin(node)


if __name__ == '__main__':
    main()
