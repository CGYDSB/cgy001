#!/usr/bin/env python3
"""
yolo_detector.py
订阅摄像头图像，用 YOLO 模型推理，发布检测结果。
发布话题: /detection_result (std_msgs/String, JSON格式)
"""

import json
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
from ultralytics import YOLO


class YoloDetector(Node):
    def __init__(self):
        super().__init__('yolo_detector')

        self.declare_parameter('model_path', 'best.pt')
        self.declare_parameter('conf_threshold', 0.5)
        self.declare_parameter('camera_topic', '/camera/image_raw')

        model_path = self.get_parameter('model_path').get_parameter_value().string_value
        self.conf  = self.get_parameter('conf_threshold').get_parameter_value().double_value
        cam_topic  = self.get_parameter('camera_topic').get_parameter_value().string_value

        self.get_logger().info(f'加载 YOLO 模型: {model_path}')
        self.model  = YOLO(model_path)
        self.bridge = CvBridge()

        self.sub = self.create_subscription(Image, cam_topic, self._cb, 10)
        self.pub = self.create_publisher(String, '/detection_result', 10)
        self.get_logger().info(f'订阅摄像头: {cam_topic}')

    def _cb(self, msg: Image):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        results = self.model(frame, conf=self.conf, verbose=False)

        detections = []
        for r in results:
            for box in r.boxes:
                detections.append({
                    'class': self.model.names[int(box.cls)],
                    'conf':  float(box.conf),
                    'xyxy':  box.xyxy[0].tolist(),
                })

        out = String()
        out.data = json.dumps({'count': len(detections), 'detections': detections})
        self.pub.publish(out)

        if detections:
            self.get_logger().info(f'检测到 {len(detections)} 个目标')


def main(args=None):
    rclpy.init(args=args)
    node = YoloDetector()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
