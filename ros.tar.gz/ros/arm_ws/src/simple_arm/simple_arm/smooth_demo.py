from lerobot_robot_viola.starai_viola import StaraiViola
from lerobot_robot_viola.config_starai_viola import StaraiViolaConfig
from pathlib import Path
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
from arm_motion import HOME, move, run_sequence

config = StaraiViolaConfig(
    port="/dev/ttyUSB0",
    id="my_awesome_staraiviola_arm",
    calibration_dir=Path.home() / ".cache/huggingface/lerobot/calibration/robots/starai_viola",
)

arm = StaraiViola(config)
arm.connect(calibrate=False)

# ─────────────────────────────────────────
# 关键帧定义
# Motor_0: 底座旋转    范围 -100~100  正=左转
# Motor_1: 大臂俯仰    范围 -100~100  负=抬起
# Motor_2: 小臂俯仰    范围 -100~100  正=折叠
# Motor_3: 小臂旋转    范围 -100~100  正=顺时针
# Motor_4: 腕部俯仰    范围 -100~100  正=下压
# Motor_5: 腕部旋转    范围 -100~100  正=顺时针
# ─────────────────────────────────────────

# ── 动作组1: 左右扫描 ──────────────────────
SCAN = [
    HOME,
    {"Motor_0":  70, "Motor_1": -80, "Motor_2": 50, "Motor_3":  0, "Motor_4": 20, "Motor_5":  0, "gripper": 50},
    {"Motor_0": -70, "Motor_1": -80, "Motor_2": 50, "Motor_3":  0, "Motor_4": 20, "Motor_5":  0, "gripper": 50},
    HOME,
]

# ── 动作组2: 前伸探测 ──────────────────────
REACH = [
    HOME,
    {"Motor_0":  0, "Motor_1": -60, "Motor_2": 30, "Motor_3":  0, "Motor_4": 10, "Motor_5":  0, "gripper": 50},
    {"Motor_0":  0, "Motor_1": -30, "Motor_2":  0, "Motor_3":  0, "Motor_4": 50, "Motor_5":  0, "gripper": 50},
    {"Motor_0":  0, "Motor_1": -60, "Motor_2": 30, "Motor_3":  0, "Motor_4": 10, "Motor_5":  0, "gripper": 50},
    HOME,
]

# ── 动作组3: 腕部画圆 ──────────────────────
WRIST_CIRCLE = [
    HOME,
    {"Motor_0":  0, "Motor_1": -50, "Motor_2": 20, "Motor_3":  0,  "Motor_4": 40, "Motor_5":  0,  "gripper": 50},
    {"Motor_0":  0, "Motor_1": -50, "Motor_2": 20, "Motor_3":  60, "Motor_4": 60, "Motor_5":  0,  "gripper": 50},
    {"Motor_0":  0, "Motor_1": -50, "Motor_2": 20, "Motor_3":  60, "Motor_4": 20, "Motor_5":  60, "gripper": 50},
    {"Motor_0":  0, "Motor_1": -50, "Motor_2": 20, "Motor_3":  0,  "Motor_4": 10, "Motor_5":  60, "gripper": 50},
    {"Motor_0":  0, "Motor_1": -50, "Motor_2": 20, "Motor_3": -60, "Motor_4": 20, "Motor_5":  0,  "gripper": 50},
    {"Motor_0":  0, "Motor_1": -50, "Motor_2": 20, "Motor_3": -60, "Motor_4": 60, "Motor_5": -60, "gripper": 50},
    {"Motor_0":  0, "Motor_1": -50, "Motor_2": 20, "Motor_3":  0,  "Motor_4": 40, "Motor_5":  0,  "gripper": 50},
    HOME,
]

# ── 动作组4: 左右搬运模拟 ─────────────────
TRANSFER = [
    HOME,
    {"Motor_0":  60, "Motor_1": -100, "Motor_2": 60, "Motor_3":  0, "Motor_4": 30, "Motor_5":  0, "gripper": 50},
    {"Motor_0":  60, "Motor_1":  -40, "Motor_2":  0, "Motor_3":  0, "Motor_4": 50, "Motor_5":  0, "gripper": 50},
    {"Motor_0":  60, "Motor_1":  -70, "Motor_2": 30, "Motor_3":  0, "Motor_4": 30, "Motor_5":  0, "gripper": 50},
    {"Motor_0": -60, "Motor_1":  -70, "Motor_2": 30, "Motor_3":  0, "Motor_4": 30, "Motor_5":  0, "gripper": 50},
    {"Motor_0": -60, "Motor_1":  -40, "Motor_2":  0, "Motor_3":  0, "Motor_4": 50, "Motor_5":  0, "gripper": 50},
    {"Motor_0": -60, "Motor_1": -100, "Motor_2": 60, "Motor_3":  0, "Motor_4": 30, "Motor_5":  0, "gripper": 50},
    HOME,
]

# ── 动作组5: 点头鞠躬 ─────────────────────
BOW = [
    HOME,
    {"Motor_0":  0, "Motor_1": -60, "Motor_2": 40, "Motor_3":  0, "Motor_4":  0, "Motor_5":  0, "gripper": 50},
    {"Motor_0":  0, "Motor_1": -30, "Motor_2": 10, "Motor_3":  0, "Motor_4": 70, "Motor_5":  0, "gripper": 50},
    {"Motor_0":  0, "Motor_1": -60, "Motor_2": 40, "Motor_3":  0, "Motor_4":  0, "Motor_5":  0, "gripper": 50},
    {"Motor_0":  0, "Motor_1": -30, "Motor_2": 10, "Motor_3":  0, "Motor_4": 70, "Motor_5":  0, "gripper": 50},
    HOME,
]

# ─────────────────────────────────────────
# 执行所有动作组
# ─────────────────────────────────────────
run_sequence(arm, "左右扫描",  SCAN)
run_sequence(arm, "前伸探测",  REACH)
run_sequence(arm, "腕部画圆",  WRIST_CIRCLE)
run_sequence(arm, "左右搬运",  TRANSFER)
run_sequence(arm, "点头鞠躬",  BOW)

move(arm, HOME, HOME)
print("全部完成")
arm.disconnect()
