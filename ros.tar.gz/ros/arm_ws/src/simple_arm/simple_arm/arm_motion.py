"""
arm_motion.py - 机械臂运动公共工具
提供插值移动、缓动函数，供 smooth_demo.py 和 pose_recorder.py 共用
"""
import math
import time

INTERVAL  = 0.08  # 每步间隔(s)
MIN_STEPS = 5     # 最小步数
MAX_STEPS = 30    # 最大步数
SCALE     = 0.3   # 步数缩放系数

HOME = {"Motor_0": 0, "Motor_1": -100, "Motor_2": 60,
        "Motor_3": 0, "Motor_4": 30,   "Motor_5": 0, "gripper": 50}


def ease_in_out(t):
    return (1 - math.cos(t * math.pi)) / 2


def calc_steps(start, end):
    """根据最大关节位移动态计算步数，避免小幅度抖动"""
    max_diff = max(abs(end[k] - start[k]) for k in start)
    steps = int(max_diff * SCALE)
    return max(MIN_STEPS, min(steps, MAX_STEPS))


def move(arm, start, end, interval=INTERVAL):
    """插值移动，ease-in-out 缓动"""
    steps = calc_steps(start, end)
    motion_ms = int(interval * 1000) + 50
    for i in range(1, steps + 1):
        t = ease_in_out(i / steps)
        pos = {k: start[k] + (end[k] - start[k]) * t for k in start}
        arm.bus.sync_write("Goal_Position", pos, motion_time=motion_ms)
        time.sleep(interval)


def run_sequence(arm, name, frames):
    """执行一组关键帧序列"""
    print(f"[{name}] 开始...")
    for i in range(len(frames) - 1):
        move(arm, frames[i], frames[i + 1])
    print(f"[{name}] 完成")
