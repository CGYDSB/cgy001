from lerobot_robot_viola.starai_viola import StaraiViola
from lerobot_robot_viola.config_starai_viola import StaraiViolaConfig
from pathlib import Path
import time

config = StaraiViolaConfig(
    port="/dev/ttyUSB0",
    id="my_awesome_staraiviola_arm",
    calibration_dir=Path.home() / ".cache/huggingface/lerobot/calibration/robots/starai_viola",
)

arm = StaraiViola(config)
arm.connect(calibrate=False)

MOTION_TIME = 3000
SLEEP = 3.5

# 初始姿态（来自 move_to_initial_position）
HOME = {"Motor_0": 0, "Motor_1": -100, "Motor_2": 60, "Motor_3": 0, "Motor_4": 30, "Motor_5": 0, "gripper": 50}

def move(action):
    arm.bus.sync_write("Goal_Position", action, motion_time=MOTION_TIME)
    time.sleep(SLEEP)

def test_motor(name, value):
    print(f"回初始位...")
    move(HOME)
    input(f"按 Enter 开始测试 {name}，将移动到 {value}...")
    pos = dict(HOME)
    pos[name] = value
    move(pos)
    input(f"{name} 动完了，观察哪个关节动了，按 Enter 继续...")

test_motor("Motor_0", 20)
test_motor("Motor_0", -20)
test_motor("Motor_1", 0)
test_motor("Motor_1", 50)
test_motor("Motor_2", -30)
test_motor("Motor_2", 90)
test_motor("Motor_3", 60)
test_motor("Motor_3", -60)
test_motor("Motor_4", 80)
test_motor("Motor_4", -50)
test_motor("Motor_5", 70)
test_motor("Motor_5", -70)

move(HOME)
print("测试完成")
arm.disconnect()
